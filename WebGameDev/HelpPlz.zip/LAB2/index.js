var express = require('express');
var app = express();
var http = require('http').Server(app);
var io = require('socket.io').listen(http);
var PORT = process.env.PORT || 3000;

var people = [];
var names = [
    "Smoocharu",
    "John",
    "King",
    "Grump",
    "Pig",
    "Dog",
    "Power",
    "Dad",
    "Duck",
    "Josh",
    "Caleb",
    "Danny",
    "Ding Dong",
    "Julian",
    "Oney"
];

app.get('/', function(req, res) {
	res.sendFile(__dirname + '/app/index.html');
});


app.use(express.static('app'));

io.on('connect', function(socket) {
    var randName = Math.floor(Math.random() * 14);
    var randX = Math.floor(Math.random() * 500);
    var randY = Math.floor(Math.random() * 500);
    socket.id = names[randName];
    var name = socket.id;
    if(people.length <= 2){
        console.log(socket.id);
        people.push({name, randX, randY});
        console.log(people);
        socket.emit('currentPlayer', randX, randY, name);
        io.emit('showPlayers', people);
        socket.on('disconnect', function() {
            console.log(people);
            console.log(socket.id + ' left');
            for (var i =0; i < people.length; i++){
                if (people[i].name === name) {
                    people.splice(i, 1);
                    break;
                }
            }
            io.emit('removePlayer', name);
        });
    }
    else{
        socket.emit("no");
    }
    socket.on('resetGame', function(){
        socket.emit('currentPlayer', randX, randY, name);
        io.emit('showPlayers', people);
    });
    socket.on('playerMoved', function(name, newX, newY){
        people.forEach(element => {
            if(people.name === name){
                element.randX = newX;
                element.randY = newY;
            }
        });
        socket.broadcast.emit('otherPlayerMove', name, newX, newY);
    });
});


http.listen(PORT, function() {
	console.log('listening on localhost:3000');
});