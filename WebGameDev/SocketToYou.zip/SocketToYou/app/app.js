var app = {
    socket: null,
    stage: null,

    setupCanvas: function() {
        var canvas = document.getElementById('game');
        canvas.width = 1200;
        canvas.height = 850;
        this.stage = new createjs.Stage(canvas);
    },

    init: function() {
        this.setupCanvas();
        this.socket = io();

        this.socket.on('list', function(people) {
            console.log(people.toString());
        });
        this.socket.on('you', function(id) {
            console.log("You are " + id);
        });

        this.socket.on('no', function(){
            console.log("You can't connect to this room, because it is full, sorry");
        });

        this.socket.on('showPlayer', function(x, y, color, id, people) {
            var player = people.indexOf(id);
            console.log(player);
            player.shape = new createjs.Shape();
            player.shape.graphics.beginFill(color).drawRect(x, y, 40, 40);
            app.stage.addChild(player.shape);
            app.stage.update();
        });

        this.socket.on('removePlayer', function(){
            app.stage.removeChild();
        });
        
    },
}

app.init();