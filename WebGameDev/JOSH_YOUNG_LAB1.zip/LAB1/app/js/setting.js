var SCREEN_WIDTH = 800;
var SCREEN_HEIGHT = 600;
var FPS = 30;
var SPEED = 200;

var gameStates = {
    MENU: 0,
    GAMEPLAY: 1,
    GAMEOVER: 2,
    INSTRUCTIONS: 3
};

