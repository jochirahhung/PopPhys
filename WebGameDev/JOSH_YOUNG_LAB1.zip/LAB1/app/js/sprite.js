function createSpriteActor(x, y, imageID)
{
    var sprite = new createjs.Sprite(app.assets.getResult(imageID));
    
    sprite.x = x;
    sprite.y = y;

    return sprite;
}