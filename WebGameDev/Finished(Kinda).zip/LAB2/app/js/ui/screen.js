function Screen(screenTitleText, buttonText, buttonCallbackFunc)
{
    createjs.Container.call(this);


    ui.makeDefaultText(this, screenTitleText, SCREEN_WIDTH / 2, 50);

    ui.makeDefaultTextButton(this, buttonText, SCREEN_WIDTH / 2, 400, buttonCallbackFunc);
}
Screen.prototype = Object.create(createjs.Container.prototype);
Screen.prototype.constructor = Screen;

function Button(buttonText, buttonCallbackFunc){
    ui.makeDefaultTextButton(this, buttonText, SCREEN_WIDTH, 0, buttonCallbackFunc);
}
Button.prototype = Object.create(createjs.Container.prototype);
Button.prototype.constructor = Screen;