function Actor(nameString, x, y, r)
{
    this.name = nameString;
    this.pos = {x: x, y: y};

    this.boundsRadius = r;

    if(DEBUG)
    {
        this.debugShape = new createjs.Shape();
        this.debugShape.graphics.beginStroke("#420DAB").drawCircle(0,0, this.boundsRadius);
        this.debugShape.x = this.pos.x;
        this.debugShape.y = this.pos.y;
        app.stage.addChild(this.debugShape);
    }
}
Actor.prototype.update = function(dt)
{
    if(DEBUG)
    {
        this.debugShape.x = this.pos.x;
        this.debugShape.y = this.pos.y;
    }  
};

function spriteActor(parent, nameString, x, y, r, imageID)
{
    Actor.call(this, nameString, x, y, r);

    this.image = new createjs.Sprite(app.assets.getResult(imageID));

    this.image.x = this.pos.x;
    this.image.y = this.pos.y;

    parent.addChild(this.image);
}
spriteActor.prototype = Object.create(Actor.prototype);
spriteActor.prototype.constructor = spriteActor;
spriteActor.prototype.update = function(dt)
{
    this.image.x = this.pos.x;
    this.image.y = this.pos.y;

    Actor.prototype.update.call(this, dt);
}



function Player(parent, x, y)
{
    spriteActor.call(this, parent, "pig", x, y, 100, "pig");

    this.image.gotoAndPlay("walk");

    this.update = function(dt)
    {
        if(app.keyboard.left.isPressed || app.keyboard.a.isPressed)
        {
            this.pos.x -= SPEED * dt;
        }
        
        if(app.keyboard.right.isPressed || app.keyboard.d.isPressed)
        {
            this.pos.x += SPEED * dt;
        }
        
        if(app.keyboard.up.isPressed || app.keyboard.w.isPressed)
        {
            this.pos.y -= SPEED * dt;
        }
        
        if(app.keyboard.down.isPressed || app.keyboard.s.isPressed)
        {
            this.pos.y += SPEED * dt;
        }
        if(app.keyboard.j.isPressed){
            SPEED = 500;
        }

        app.wumpas.forEach(function(entry){
            if(areActorsColliding(this, entry))
            {
                entry.onCollect();
                app.value += 25;
                createjs.Sound.play( "apple" );
            }
        }, this);

        spriteActor.prototype.update.call(this, dt);
    }
}
Player.prototype = Object.create(spriteActor.prototype);
Player.prototype.constructor = Player;