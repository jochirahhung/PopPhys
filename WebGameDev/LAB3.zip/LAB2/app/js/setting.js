
var SCREEN_WIDTH = 1200;
var SCREEN_HEIGHT = 800;
var FPS = 30;
var SPEED = 200;

var eStates = {
    MENUS: 0,
    GAMEPLAY: 1,
    GAMEOVER: 2,
    INSTRUCTIONS: 3
};

var DEBUG = true;

