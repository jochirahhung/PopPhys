var app = {
    stage: null,


    gameState: 0,

    gameObject: null,
    wumpas: [],
    pins: [],


    elapsedTime: 0, 

    mousePos: {x: 0, y: 0},
    keyboard: {
        left : { keycode: 37, isPressed: false},
        up : { keycode: 38, isPressed: false},
        right : { keycode: 39, isPressed: false},
        down : { keycode: 40, isPressed: false},
        w : { keycode: 87, isPressed: false},
        a : { keycode: 65, isPressed: false},
        s : { keycode: 83, isPressed: false},
        d : { keycode: 68, isPressed: false},
        j : { keycode: 74, isPressed: false},
        spacebar : { keycode: 32, isPressed: false}
    },

    assets: null,

    value: 0,
    screen: null,
    button1: null,
    button2: null,

    setupCanvas: function()
    {
        var canvas = document.getElementById("game");
        canvas.width = SCREEN_WIDTH;
        canvas.height = SCREEN_HEIGHT;
        this.stage = new createjs.Stage(canvas);
    },

    beginLoad: function()
    {
        manifest = [
            {
                src: "js/actors/actor.js",
            },
            {
                src: "js/actors/bitmapactor.js",
            },
            {
                src: "js/setting.js",
            },
            {
                src: "js/utils.js",
            },
            {
                src: "js/ui/ui.js",
            },
            {
                src: "js/ui/screen.js",
            },
            {
                src: "media/audio/Click2.mp3",
                id: "click"
            },
            {
                src: "media/images/wumpa.png",
                id: "wumpa"
            },
            {
                src: "media/images/spike.png",
                id: "spike"
            },
            {
                src: "media/images/grass.png",
                id: "grass"
            },
            {
                src: "media/images/appleTitle.png",
                id: "appleTitle"
            },
            {
                src: "media/audio/Apple.mp3",
                id: "apple"
            },
            {
                src: "media/images/pigsheet.json",
                id:"pig",
                type:"spritesheet",
                crossOrigin:true
            },
        ];

        this.assets = new createjs.LoadQueue(true); 

        createjs.Sound.alternateExtensions = ["ogg"];

        this.assets.installPlugin(createjs.Sound);


        this.assets.on("complete", function (event) {
            app.init();
        });

        this.assets.loadManifest(manifest);
    },

    init: function()
    {
        this.setupCanvas();
        this.setState(eStates.MENUS);
        console.log(app.gameState);

        this.stage.enableMouseOver();

        this.stage.on("stagemousemove", function(event) {
            app.mousePos.x = Math.floor(event.stageX);
            app.mousePos.y = Math.floor(event.stageY);

        });
        
        this.stage.on("stagemousedown", function (event) {
            app.handleMouseDown(event);
        });

        document.onkeydown = this.handleKeyDown;
        document.onkeyup = this.handleKeyUp;

        createjs.Ticker.addEventListener("tick", this.update);
        createjs.Ticker.framerate = FPS;
    },


    update: function(event)
    {
        app.stage.update(event);
        var dt = event.delta / 1000;
        app.elapsedTime += dt;


        if(app.gameState === eStates.MENUS)
        {
            app.value = 0;
            document.getElementById("score").innerHTML = "Score: " + app.value;
        }
        else if(app.gameState === eStates.GAMEPLAY)
        {
            document.getElementById("score").innerHTML = "Score: " + app.value;
            app.gameObject.update(dt);

            app.wumpas.forEach(function(entry) {
                entry.update(dt);
            });
        }

    },


    handleMouseDown: function(event)
    {
        createjs.Sound.play( "click" );
    },

    handleKeyDown: function(event)
    {
        if(!evt){ var evt = window.event; }

        switch(evt.keyCode) {
            case app.keyboard.left.keycode:     
                app.keyboard.left.isPressed = true; 
                console.log("Left Arrow");
                return false;
            case app.keyboard.up.keycode:       
                app.keyboard.up.isPressed = true; 
                console.log("Up Arrow");
                return false;
            case app.keyboard.right.keycode:    
                app.keyboard.right.isPressed = true; 
                console.log("Right Arrow");
                return false;
            case app.keyboard.down.keycode:     
                app.keyboard.down.isPressed = true; 
                console.log("Down Arrow");
                return false;
            case app.keyboard.spacebar.keycode: 
                app.keyboard.spacebar.isPressed = true;
                console.log("Spacebar");
                return false;
            case app.keyboard.w.keycode:
                app.keyboard.w.isPressed = true;
                console.log("W Key");
                return false;
            case app.keyboard.a.keycode:
                app.keyboard.a.isPressed = true;
                console.log("A Key");
                return false;
            case app.keyboard.s.keycode:
                app.keyboard.s.isPressed = true;
                console.log("S Key");
                return false;
            case app.keyboard.j.keycode:
                app.keyboard.j.isPressed = true;
                console.log("J Key");
                document.getElementById("timer").innerHTML = "God Mode";
                return false;
            case app.keyboard.d.keycode:
                app.keyboard.d.isPressed = true;
                console.log("D Key");
                return false;
        }
    },

    handleKeyUp: function(event)
    {
        if(!evt){ var evt = window.event; }  

        switch(evt.keyCode) {
            case app.keyboard.left.keycode:     
                app.keyboard.left.isPressed = false; 
                return false;
            case app.keyboard.up.keycode:       
                app.keyboard.up.isPressed = false; 
                return false;
            case app.keyboard.right.keycode:    
                app.keyboard.right.isPressed = false; 
                return false;
            case app.keyboard.down.keycode:     
                app.keyboard.down.isPressed = false; 
                return false;
            case app.keyboard.spacebar.keycode: 
                app.keyboard.spacebar.isPressed = false; 
                return false;
            case app.keyboard.w.keycode: 
                app.keyboard.w.isPressed = false; 
                return false;
            case app.keyboard.a.keycode: 
                app.keyboard.a.isPressed = false; 
                return false;
            case app.keyboard.s.keycode: 
                app.keyboard.s.isPressed = false; 
                return false;
            case app.keyboard.d.keycode: 
                app.keyboard.d.isPressed = false; 
                return false;
        }
    },


    setState: function(newState)
    {
        this.gameState = newState;

        if(this.gameState === eStates.MENUS)
        {

            var stageBG = new createjs.Shape();
            var back = new bitmapActor(this.stage, "grass", 600, 0, 100, "grass");
            stageBG.graphics.beginBitmapFill(back, "repeat").drawRect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
            var text = new createjs.Text("Game made by Josh Young", "20px Galada", "white");
            var text2 = new createjs.Text("Press J to make the game easier by going faster", "20px Arial", "white");
            text.x = 100;
            text2.x = 450;
            this.stage.addChild(stageBG);
            this.stage.addChild(text);
            this.stage.addChild(text2);

            this.screen = new Screen("Apple Collector", "Instructions", function() {
                app.screen.visible = false;
                app.setState(eStates.INSTRUCTIONS);
            })
            this.stage.addChild(this.screen);

            
        }
        else if(this.gameState === eStates.INSTRUCTIONS)
        {
            this.screen = new Screen("Please use the Arrow keys, or the wasd, avoid the birds or spikes", "Play Game", function(){
                app.screen.visible = false;
                app.setState(eStates.GAMEPLAY);
            })
            this.stage.addChild(this.screen);
        }
        else if(this.gameState === eStates.GAMEPLAY)
        {
           this.resetGame();
        }
        else if(this.gameState === eStates.GAMEOVER){
            app.stage.removeChild(this.screen);

            var stageBG = new createjs.Shape();
            var back = new bitmapActor(this.stage, "grass", 600, 0, 100, "grass");
            stageBG.graphics.beginBitmapFill(back, "repeat").drawRect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
            this.stage.addChild(stageBG);
            app.value = 0;
            this.wumpas = [];
            this.pins = [];
            this.screen = new Screen("YOU LOSE", "Try Again", function() {
                app.screen.visible = false;
                app.setState(eStates.INSTRUCTIONS);
            })
            this.stage.addChild(this.screen);
        }
    },

    resetGame: function()
    {
        this.gameObject = new Player(this.stage, 600, 400);

        for(var i = 0; i < 6; i++)
        {
            var pos = getRandomPointOnScreen();
            this.wumpas.push(new collectibleActor(this.stage, "wumpa" + i, pos.x, pos.y, 25, "wumpa"));
        }
        for(var j = 0; j < 3; j++)
        {
            var pos = getRandomPointOnScreen();
            this.pins.push(new collectibleActor(this.stage, "spike" + j, pos.x, pos.y, 25, "spike"));
        }
    },
}